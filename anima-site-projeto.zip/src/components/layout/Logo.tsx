'use client'

import Image from 'next/image'
import Link from 'next/link'

export default function Logo() {
  return (
    <div className="flex items-center">
      <Link href="/" className="flex items-center">
        <Image 
          src="/images/anima-logo.jpg" 
          alt="Ânima Consultório Médico" 
          width={50} 
          height={50}
          className="mr-2"
        />
        <span className="text-2xl font-bold text-white">Ânima</span>
      </Link>
    </div>
  )
}
