'use client'

import Link from 'next/link'
import Image from 'next/image'
import { useState } from 'react'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <header className="bg-gradient-to-r from-blue-600 to-teal-500 text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Image 
                src="/images/anima-logo.jpg" 
                alt="Ânima Consultório Médico" 
                width={40} 
                height={40}
                className="mr-2 rounded-md"
              />
              <span className="text-2xl font-bold">Ânima</span>
            </Link>
            <span className="ml-2 text-sm md:text-base">Consultório Médico</span>
          </div>

          {/* Menu para desktop */}
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className="hover:text-blue-200 transition-colors">
              Início
            </Link>
            <Link href="/sobre" className="hover:text-blue-200 transition-colors">
              Sobre Nós
            </Link>
            <Link href="/doencas" className="hover:text-blue-200 transition-colors">
              Doenças Respiratórias
            </Link>
            <Link href="/medicacoes" className="hover:text-blue-200 transition-colors">
              Medicações
            </Link>
            <Link href="/servicos" className="hover:text-blue-200 transition-colors">
              Serviços
            </Link>
            <Link href="/videos" className="hover:text-blue-200 transition-colors">
              Vídeos
            </Link>
            <Link href="/agendamento" className="hover:text-blue-200 transition-colors">
              Agendamento
            </Link>
            <Link href="/contato" className="hover:text-blue-200 transition-colors">
              Contato
            </Link>
          </nav>

          {/* Botão do menu mobile */}
          <button 
            className="md:hidden text-white focus:outline-none"
            onClick={toggleMenu}
          >
            <svg 
              className="w-6 h-6" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {isMenuOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>

        {/* Menu mobile */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-2 space-y-3">
            <Link href="/" className="block hover:text-blue-200 transition-colors">
              Início
            </Link>
            <Link href="/sobre" className="block hover:text-blue-200 transition-colors">
              Sobre Nós
            </Link>
            <Link href="/doencas" className="block hover:text-blue-200 transition-colors">
              Doenças Respiratórias
            </Link>
            <Link href="/medicacoes" className="block hover:text-blue-200 transition-colors">
              Medicações
            </Link>
            <Link href="/servicos" className="block hover:text-blue-200 transition-colors">
              Serviços
            </Link>
            <Link href="/videos" className="block hover:text-blue-200 transition-colors">
              Vídeos
            </Link>
            <Link href="/agendamento" className="block hover:text-blue-200 transition-colors">
              Agendamento
            </Link>
            <Link href="/contato" className="block hover:text-blue-200 transition-colors">
              Contato
            </Link>
          </nav>
        )}
      </div>
    </header>
  )
}
