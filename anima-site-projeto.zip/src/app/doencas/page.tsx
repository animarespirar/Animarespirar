'use client'

import Link from 'next/link'

export default function DoencasRespiratorias() {
  return (
    <div className="min-h-screen py-12">
      {/* Banner da página */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Doenças Respiratórias</h1>
          <p className="text-xl max-w-3xl">
            Conheça as principais doenças respiratórias, seus sintomas, tratamentos e medidas preventivas.
          </p>
        </div>
      </section>

      {/* Introdução */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">O que são Doenças Respiratórias?</h2>
            <p className="text-gray-600 mb-6">
              As doenças respiratórias são condições que afetam o sistema respiratório, incluindo vias aéreas, 
              pulmões e passagens nasais. Estas doenças podem variar de infecções agudas, como resfriados comuns 
              e pneumonia, a condições crônicas como asma, doença pulmonar obstrutiva crônica (DPOC) e câncer de pulmão.
            </p>
            <p className="text-gray-600 mb-6">
              O diagnóstico precoce e o tratamento adequado são fundamentais para controlar os sintomas e 
              melhorar a qualidade de vida dos pacientes. No Consultório Ânima, oferecemos atendimento 
              especializado para diversas condições respiratórias, com médicos experientes e equipamentos modernos.
            </p>
          </div>
        </div>
      </section>

      {/* Lista de doenças */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-12">Principais Doenças Respiratórias</h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Asma */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Asma</h3>
                <p className="text-gray-600 mb-4">
                  A asma é uma doença crônica caracterizada pela inflamação e estreitamento das vias aéreas, 
                  causando dificuldade para respirar, chiado no peito, tosse e sensação de aperto no peito.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Sintomas comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Falta de ar</li>
                    <li>Chiado no peito (sibilo)</li>
                    <li>Tosse persistente, especialmente à noite</li>
                    <li>Sensação de aperto no peito</li>
                    <li>Dificuldade para realizar atividades físicas</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tratamento:</h4>
                  <p className="text-gray-600">
                    O tratamento da asma geralmente inclui medicamentos de controle de longo prazo para reduzir 
                    a inflamação e prevenir sintomas, além de medicamentos de alívio rápido para uso durante crises. 
                    Um plano de ação personalizado é essencial para o controle eficaz da asma.
                  </p>
                </div>
              </div>
            </div>

            {/* DPOC */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Doença Pulmonar Obstrutiva Crônica (DPOC)</h3>
                <p className="text-gray-600 mb-4">
                  A DPOC é um grupo de doenças pulmonares que bloqueiam o fluxo de ar e dificultam a respiração. 
                  Enfisema e bronquite crônica são as condições mais comuns que contribuem para a DPOC.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Sintomas comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Falta de ar, especialmente durante atividades físicas</li>
                    <li>Chiado no peito</li>
                    <li>Aperto no peito</li>
                    <li>Tosse crônica, com ou sem catarro</li>
                    <li>Fadiga e perda de peso (em estágios avançados)</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tratamento:</h4>
                  <p className="text-gray-600">
                    Embora a DPOC não tenha cura, o tratamento pode ajudar a controlar os sintomas e reduzir o risco 
                    de complicações. As opções incluem broncodilatadores, corticosteroides inalados, terapia com 
                    oxigênio e, em casos graves, cirurgia. Parar de fumar é essencial para retardar a progressão da doença.
                  </p>
                </div>
              </div>
            </div>

            {/* Pneumonia */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Pneumonia</h3>
                <p className="text-gray-600 mb-4">
                  A pneumonia é uma infecção que inflama os sacos aéreos em um ou ambos os pulmões. Os sacos aéreos 
                  podem se encher de líquido ou pus, causando tosse com catarro, febre, calafrios e dificuldade para respirar.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Sintomas comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Tosse com catarro (que pode conter sangue)</li>
                    <li>Febre, suores e calafrios</li>
                    <li>Dificuldade para respirar</li>
                    <li>Dor no peito ao respirar ou tossir</li>
                    <li>Fadiga e confusão mental (especialmente em idosos)</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tratamento:</h4>
                  <p className="text-gray-600">
                    O tratamento da pneumonia depende do tipo e gravidade da infecção. Antibióticos são usados para 
                    pneumonia bacteriana, enquanto antivirais podem ser prescritos para pneumonia viral. Repouso, 
                    hidratação adequada e medicamentos para aliviar a febre e a dor também são importantes.
                  </p>
                </div>
              </div>
            </div>

            {/* Rinite Alérgica */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Rinite Alérgica</h3>
                <p className="text-gray-600 mb-4">
                  A rinite alérgica é uma reação alérgica que causa inflamação na mucosa nasal. É frequentemente 
                  desencadeada por alérgenos como pólen, ácaros, pelos de animais ou mofo.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Sintomas comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Coriza (nariz escorrendo)</li>
                    <li>Espirros frequentes</li>
                    <li>Congestão nasal</li>
                    <li>Coceira no nariz, olhos, garganta ou céu da boca</li>
                    <li>Olhos lacrimejantes e vermelhos</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tratamento:</h4>
                  <p className="text-gray-600">
                    O tratamento da rinite alérgica inclui evitar alérgenos conhecidos, medicamentos como anti-histamínicos, 
                    descongestionantes e sprays nasais com corticosteroides. Em casos mais graves, a imunoterapia 
                    (vacinas contra alergia) pode ser recomendada.
                  </p>
                </div>
              </div>
            </div>

            {/* Tuberculose */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Tuberculose</h3>
                <p className="text-gray-600 mb-4">
                  A tuberculose (TB) é uma doença infecciosa causada pela bactéria Mycobacterium tuberculosis. 
                  Ela afeta principalmente os pulmões, mas pode atingir outros órgãos.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Sintomas comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Tosse persistente (por mais de três semanas), às vezes com sangue</li>
                    <li>Dor no peito</li>
                    <li>Perda de peso não intencional</li>
                    <li>Fadiga</li>
                    <li>Febre e suores noturnos</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tratamento:</h4>
                  <p className="text-gray-600">
                    O tratamento da tuberculose envolve tomar antibióticos por um longo período, geralmente de seis a nove meses. 
                    É crucial completar todo o tratamento, mesmo quando os sintomas melhoram, para evitar o desenvolvimento 
                    de resistência aos medicamentos.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Prevenção */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Prevenção de Doenças Respiratórias</h2>
            <p className="text-gray-600 mb-6">
              Muitas doenças respiratórias podem ser prevenidas ou seus sintomas minimizados com algumas medidas simples:
            </p>
            <ul className="list-disc pl-5 text-gray-600 space-y-3 mb-8">
              <li>
                <span className="font-semibold">Não fume e evite o fumo passivo:</span> O tabagismo é a principal causa 
                evitável de doenças respiratórias.
              </li>
              <li>
                <span className="font-semibold">Mantenha uma boa higiene:</span> Lave as mãos regularmente, especialmente 
                durante a temporada de gripes e resfriados.
              </li>
              <li>
                <span className="font-semibold">Evite alérgenos conhecidos:</span> Se você tem alergias, minimize a exposição 
                a gatilhos como pólen, ácaros e pelos de animais.
              </li>
              <li>
                <span className="font-semibold">Mantenha sua casa limpa:</span> Reduza a poeira, mofo e outros alérgenos em casa.
              </li>
              <li>
                <span className="font-semibold">Vacine-se:</span> Mantenha suas vacinas em dia, incluindo a vacina anual contra 
                a gripe e a vacina pneumocócica.
              </li>
              <li>
                <span className="font-semibold">Pratique exercícios regularmente:</span> A atividade física fortalece o sistema 
                respiratório e melhora a capacidade pulmonar.
              </li>
              <li>
                <span className="font-semibold">Mantenha uma alimentação saudável:</span> Uma dieta equilibrada fortalece o 
                sistema imunológico.
              </li>
            </ul>
            <p className="text-gray-600">
              Se você apresenta sintomas persistentes de problemas respiratórios, é importante buscar atendimento médico 
              especializado. No Consultório Ânima, oferecemos diagnóstico preciso e tratamento personalizado para diversas 
              condições respiratórias.
            </p>
          </div>
        </div>
      </section>

      {/* Chamada para ação */}
      <section className="py-12 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Está com sintomas respiratórios?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Não deixe que problemas respiratórios afetem sua qualidade de vida. 
            Agende uma consulta com nossos especialistas e receba o diagnóstico e tratamento adequados.
          </p>
          <a href="https://bio.link/animarespirar" target="_blank" rel="noopener noreferrer" className="bg-blue-600 text-white hover:bg-blue-700 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
            Agende sua Consulta
          </a>
        </div>
      </section>
    </div>
  )
}
