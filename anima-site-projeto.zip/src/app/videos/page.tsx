'use client'

import Link from 'next/link'
import { useState } from 'react'

export default function Videos() {
  // Array de vídeos relacionados a doenças respiratórias e medicações
  const videos = [
    {
      id: '1',
      title: 'Como usar corretamente um inalador',
      description: 'Aprenda a técnica correta para utilizar inaladores pressurizados (bombinhas) e obter o máximo benefício do seu medicamento.',
      embedId: 'dummyId1', // Substituir por ID real do YouTube
      category: 'Medicações'
    },
    {
      id: '2',
      title: 'Entendendo a Asma: Causas, Sintomas e Tratamentos',
      description: 'Neste vídeo, explicamos o que é a asma, quais são seus principais sintomas e as opções de tratamento disponíveis atualmente.',
      embedId: 'dummyId2', // Substituir por ID real do YouTube
      category: 'Doenças'
    },
    {
      id: '3',
      title: 'DPOC: O que você precisa saber',
      description: 'Informações essenciais sobre a Doença Pulmonar Obstrutiva Crônica, seus fatores de risco e como gerenciar a condição.',
      embedId: 'dummyId3', // Substituir por ID real do YouTube
      category: 'Doenças'
    },
    {
      id: '4',
      title: 'Exercícios respiratórios para melhorar a capacidade pulmonar',
      description: 'Série de exercícios simples que podem ser feitos em casa para fortalecer os músculos respiratórios e melhorar a respiração.',
      embedId: 'dummyId4', // Substituir por ID real do YouTube
      category: 'Exercícios'
    },
    {
      id: '5',
      title: 'Como usar um nebulizador corretamente',
      description: 'Guia passo a passo sobre como utilizar um nebulizador para administração de medicamentos respiratórios.',
      embedId: 'dummyId5', // Substituir por ID real do YouTube
      category: 'Medicações'
    },
    {
      id: '6',
      title: 'Alergias respiratórias: Prevenção e tratamento',
      description: 'Dicas práticas para identificar e evitar alérgenos comuns, além de opções de tratamento para alergias respiratórias.',
      embedId: 'dummyId6', // Substituir por ID real do YouTube
      category: 'Doenças'
    }
  ]

  // Estado para filtrar vídeos por categoria
  const [filtro, setFiltro] = useState('Todos')

  // Função para filtrar vídeos
  const videosFiltrados = filtro === 'Todos' 
    ? videos 
    : videos.filter(video => video.category === filtro)

  return (
    <div className="min-h-screen py-12">
      {/* Banner da página */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Vídeos Educativos</h1>
          <p className="text-xl max-w-3xl">
            Assista a vídeos informativos sobre doenças respiratórias, uso correto de medicações e dicas de saúde.
          </p>
        </div>
      </section>

      {/* Filtros */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <div className="flex flex-wrap justify-center gap-4">
              <button 
                onClick={() => setFiltro('Todos')}
                className={`px-4 py-2 rounded-full ${
                  filtro === 'Todos' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-colors`}
              >
                Todos os vídeos
              </button>
              <button 
                onClick={() => setFiltro('Doenças')}
                className={`px-4 py-2 rounded-full ${
                  filtro === 'Doenças' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-colors`}
              >
                Doenças Respiratórias
              </button>
              <button 
                onClick={() => setFiltro('Medicações')}
                className={`px-4 py-2 rounded-full ${
                  filtro === 'Medicações' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-colors`}
              >
                Medicações
              </button>
              <button 
                onClick={() => setFiltro('Exercícios')}
                className={`px-4 py-2 rounded-full ${
                  filtro === 'Exercícios' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                } transition-colors`}
              >
                Exercícios Respiratórios
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Lista de vídeos */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-2xl font-bold text-center text-gray-800 mb-8">
              {filtro === 'Todos' ? 'Todos os Vídeos' : `Vídeos sobre ${filtro}`}
            </h2>
            
            {videosFiltrados.length === 0 ? (
              <p className="text-center text-gray-600">Nenhum vídeo encontrado nesta categoria.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {videosFiltrados.map(video => (
                  <div key={video.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                    <div className="aspect-w-16 aspect-h-9 bg-gray-200">
                      {/* Placeholder para o vídeo do YouTube */}
                      <div className="w-full h-full flex items-center justify-center">
                        <p className="text-gray-500">
                          {/* Em um ambiente real, seria substituído pelo iframe do YouTube */}
                          <iframe 
                            className="w-full h-full"
                            src={`https://www.youtube.com/embed/${video.embedId}`}
                            title={video.title}
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          ></iframe>
                        </p>
                      </div>
                    </div>
                    <div className="p-6">
                      <span className="inline-block px-3 py-1 text-sm font-medium bg-blue-100 text-blue-800 rounded-full mb-3">
                        {video.category}
                      </span>
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{video.title}</h3>
                      <p className="text-gray-600 mb-4">{video.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Seção de informações adicionais */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Sobre Nossos Vídeos Educativos</h2>
            <p className="text-gray-600 mb-6">
              No Consultório Ânima, acreditamos que a educação do paciente é uma parte fundamental do tratamento. 
              Nossos vídeos educativos são cuidadosamente selecionados para fornecer informações precisas e 
              atualizadas sobre doenças respiratórias, uso correto de medicações e práticas para melhorar a 
              saúde respiratória.
            </p>
            <p className="text-gray-600 mb-6">
              Todos os vídeos são revisados por nossa equipe médica para garantir a qualidade e precisão das 
              informações apresentadas. No entanto, é importante lembrar que estes vídeos têm caráter informativo 
              e não substituem a consulta médica.
            </p>
            <div className="bg-blue-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Tem sugestões de temas para novos vídeos?</h3>
              <p className="text-gray-600 mb-4">
                Estamos sempre buscando melhorar nosso conteúdo educativo. Se você tem sugestões de temas 
                que gostaria de ver abordados em nossos vídeos, entre em contato conosco.
              </p>
              <Link href="/contato" className="text-blue-600 hover:text-blue-800 font-medium">
                Enviar sugestão →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Chamada para ação */}
      <section className="py-12 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Tem dúvidas sobre sua condição respiratória?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Nossos especialistas estão prontos para ajudar você a entender melhor sua condição e 
            desenvolver um plano de tratamento personalizado.
          </p>
          <Link href="/agendamento" className="bg-blue-600 text-white hover:bg-blue-700 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
            Agende uma Consulta
          </Link>
        </div>
      </section>
    </div>
  )
}
