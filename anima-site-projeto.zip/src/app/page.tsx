'use client'

import Image from 'next/image'
import Link from 'next/link'

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Banner Principal */}
      <section className="relative bg-gradient-to-r from-blue-600 to-teal-500 text-white py-20">
        <div className="container mx-auto px-4 z-10 relative">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Ânima Consultório Médico</h1>
            <p className="text-xl md:text-2xl mb-8">Cuidando da sua saúde respiratória com excelência e dedicação</p>
            <a href="https://bio.link/animarespirar" target="_blank" rel="noopener noreferrer" className="bg-white text-blue-600 hover:bg-blue-100 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
              Agende sua Consulta
            </a>
          </div>
        </div>
        <div className="absolute inset-0 bg-black opacity-20"></div>
      </section>

      {/* Seção de Boas-vindas */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Bem-vindo ao Consultório Ânima</h2>
            <p className="text-lg text-gray-600 mb-8">
              Somos um consultório médico especializado em pneumologia e alergologia, 
              oferecendo atendimento de excelência para pacientes com doenças respiratórias. 
              Nossa equipe de especialistas está comprometida em proporcionar o melhor 
              diagnóstico e tratamento para melhorar sua qualidade de vida.
            </p>
          </div>
        </div>
      </section>

      {/* Seção de Médicos */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Nossa Equipe Médica</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Médico 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Dra. Jucielle Marcelina da Silva Saraiva</h3>
                <p className="text-blue-600 font-medium mb-4">Pneumologista</p>
                <p className="text-gray-600 mb-4">
                  Especialista em doenças respiratórias, com vasta experiência no diagnóstico 
                  e tratamento de condições como asma, DPOC, pneumonia e outras patologias pulmonares.
                </p>
                <div className="flex items-center text-gray-500">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                  </svg>
                  <span>CRM: XXXXX</span>
                </div>
              </div>
            </div>
            
            {/* Médico 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2">Dr. Jailson Pedreira Lopes</h3>
                <p className="text-blue-600 font-medium mb-4">Pneumologista e Alergologista</p>
                <p className="text-gray-600 mb-4">
                  Especialista em pneumologia e alergologia, com foco no tratamento de alergias 
                  respiratórias, asma alérgica, rinite e outras condições relacionadas ao sistema imunológico.
                </p>
                <div className="flex items-center text-gray-500">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                  </svg>
                  <span>CRM: XXXXX</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Serviços */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Nossos Serviços</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Serviço 1 */}
            <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Testes Alérgicos</h3>
              <p className="text-gray-600">
                Realizamos testes alérgicos completos para identificar substâncias que podem 
                estar causando reações alérgicas. Nossos testes são seguros, precisos e 
                fornecem resultados que ajudam a desenvolver um plano de tratamento personalizado.
              </p>
            </div>
            
            {/* Serviço 2 */}
            <div className="bg-teal-50 rounded-lg p-6 border-l-4 border-teal-500">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Espirometria</h3>
              <p className="text-gray-600">
                A espirometria é um exame que avalia a função pulmonar, medindo a quantidade 
                e a velocidade do ar que você consegue inspirar e expirar. Este teste é 
                fundamental para o diagnóstico e acompanhamento de doenças respiratórias 
                como asma e DPOC.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Seção de Chamada para Ação */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-teal-500 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Cuide da sua saúde respiratória</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Não deixe que problemas respiratórios afetem sua qualidade de vida. 
            Nossa equipe está pronta para ajudar você a respirar melhor.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="https://bio.link/animarespirar" target="_blank" rel="noopener noreferrer" className="bg-white text-blue-600 hover:bg-blue-100 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
              Agende sua Consulta
            </a>
            <Link href="/contato" className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-blue-600 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
              Entre em Contato
            </Link>
          </div>
        </div>
      </section>

      {/* Seção de Localização */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Nossa Localização</h2>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <div className="mb-6 h-64 bg-gray-300 rounded-lg flex items-center justify-center">
              {/* Aqui será inserido o mapa do Google Maps */}
              <p className="text-gray-600">Mapa será carregado aqui</p>
            </div>
            
            <div className="text-center">
              <h3 className="text-xl font-bold text-gray-800 mb-2">Ânima Consultório Médico</h3>
              <p className="text-gray-600 mb-1">Rua João Rosa, Centro</p>
              <p className="text-gray-600 mb-4">Igarapé, MG</p>
              <p className="text-gray-600">
                <span className="font-medium">Horário de Atendimento:</span> Segunda a Sexta, 8h às 18h
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
