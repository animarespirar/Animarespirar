'use client'

import { useState } from 'react'
import Link from 'next/link'

export default function Agendamento() {
  // Estados para o formulário
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [telefone, setTelefone] = useState('')
  const [data, setData] = useState('')
  const [horario, setHorario] = useState('')
  const [medico, setMedico] = useState('')
  const [tipoConsulta, setTipoConsulta] = useState('')
  const [sintomas, setSintomas] = useState('')
  const [enviado, setEnviado] = useState(false)
  const [erro, setErro] = useState('')

  // Função para lidar com o envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault()
    
    // Validação básica
    if (!nome || !email || !telefone || !data || !horario || !medico || !tipoConsulta) {
      setErro('Por favor, preencha todos os campos obrigatórios.')
      return
    }
    
    // Em um ambiente real, aqui seria feita a integração com um backend
    // para processar o agendamento
    
    // Simulando sucesso no envio
    setEnviado(true)
    setErro('')
    
    // Limpar o formulário
    setNome('')
    setEmail('')
    setTelefone('')
    setData('')
    setHorario('')
    setMedico('')
    setTipoConsulta('')
    setSintomas('')
  }

  return (
    <div className="min-h-screen py-12">
      {/* Banner da página */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Agendamento de Consultas</h1>
          <p className="text-xl max-w-3xl">
            Agende sua consulta com nossos especialistas em pneumologia e alergologia de forma rápida e fácil.
          </p>
        </div>
      </section>

      {/* Seção de agendamento */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {enviado ? (
              <div className="bg-green-50 border-l-4 border-green-500 p-6 rounded-lg mb-8">
                <h2 className="text-2xl font-bold text-green-700 mb-4">Solicitação de Agendamento Enviada!</h2>
                <p className="text-gray-600 mb-6">
                  Recebemos sua solicitação de agendamento. Nossa equipe entrará em contato em breve 
                  para confirmar a data e horário da sua consulta.
                </p>
                <button 
                  onClick={() => setEnviado(false)} 
                  className="bg-green-600 text-white hover:bg-green-700 transition-colors px-6 py-3 rounded-md font-medium"
                >
                  Fazer Novo Agendamento
                </button>
              </div>
            ) : (
              <>
                <h2 className="text-2xl font-bold text-gray-800 mb-6">Solicite seu Agendamento</h2>
                <p className="text-gray-600 mb-8">
                  Preencha o formulário abaixo para solicitar uma consulta. Nossa equipe entrará em contato 
                  para confirmar a disponibilidade e finalizar seu agendamento.
                </p>
                
                {erro && (
                  <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                    <p className="text-red-700">{erro}</p>
                  </div>
                )}
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Dados pessoais */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Dados Pessoais</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-1">
                          Nome Completo *
                        </label>
                        <input
                          type="text"
                          id="nome"
                          value={nome}
                          onChange={(e) => setNome(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                          E-mail *
                        </label>
                        <input
                          type="email"
                          id="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="telefone" className="block text-sm font-medium text-gray-700 mb-1">
                          Telefone/Celular *
                        </label>
                        <input
                          type="tel"
                          id="telefone"
                          value={telefone}
                          onChange={(e) => setTelefone(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          placeholder="(XX) XXXXX-XXXX"
                          required
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Dados da consulta */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Dados da Consulta</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="data" className="block text-sm font-medium text-gray-700 mb-1">
                          Data Preferencial *
                        </label>
                        <input
                          type="date"
                          id="data"
                          value={data}
                          onChange={(e) => setData(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="horario" className="block text-sm font-medium text-gray-700 mb-1">
                          Horário Preferencial *
                        </label>
                        <select
                          id="horario"
                          value={horario}
                          onChange={(e) => setHorario(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        >
                          <option value="">Selecione um horário</option>
                          <option value="Manhã - 8h às 12h">Manhã - 8h às 12h</option>
                          <option value="Tarde - 13h às 18h">Tarde - 13h às 18h</option>
                        </select>
                      </div>
                      <div>
                        <label htmlFor="medico" className="block text-sm font-medium text-gray-700 mb-1">
                          Médico *
                        </label>
                        <select
                          id="medico"
                          value={medico}
                          onChange={(e) => setMedico(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        >
                          <option value="">Selecione um médico</option>
                          <option value="Dra. Jucielle Marcelina da Silva Saraiva">Dra. Jucielle Marcelina da Silva Saraiva - Pneumologista</option>
                          <option value="Dr. Jailson Pedreira Lopes">Dr. Jailson Pedreira Lopes - Pneumologista e Alergologista</option>
                        </select>
                      </div>
                      <div>
                        <label htmlFor="tipoConsulta" className="block text-sm font-medium text-gray-700 mb-1">
                          Tipo de Consulta *
                        </label>
                        <select
                          id="tipoConsulta"
                          value={tipoConsulta}
                          onChange={(e) => setTipoConsulta(e.target.value)}
                          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                          required
                        >
                          <option value="">Selecione o tipo</option>
                          <option value="Primeira consulta">Primeira consulta</option>
                          <option value="Retorno">Retorno</option>
                          <option value="Teste alérgico">Teste alérgico</option>
                          <option value="Espirometria">Espirometria</option>
                        </select>
                      </div>
                    </div>
                    <div className="mt-6">
                      <label htmlFor="sintomas" className="block text-sm font-medium text-gray-700 mb-1">
                        Descreva seus sintomas ou motivo da consulta (opcional)
                      </label>
                      <textarea
                        id="sintomas"
                        value={sintomas}
                        onChange={(e) => setSintomas(e.target.value)}
                        rows={4}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                      ></textarea>
                    </div>
                  </div>
                  
                  {/* Termos e envio */}
                  <div className="bg-gray-50 p-6 rounded-lg">
                    <div className="flex items-start mb-6">
                      <input
                        id="termos"
                        type="checkbox"
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded mt-1"
                        required
                      />
                      <label htmlFor="termos" className="ml-2 block text-sm text-gray-700">
                        Concordo com o armazenamento dos meus dados para fins de agendamento e contato. 
                        Estou ciente que posso solicitar a exclusão dos meus dados a qualquer momento.
                      </label>
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-blue-600 text-white hover:bg-blue-700 transition-colors px-6 py-3 rounded-md font-medium"
                    >
                      Solicitar Agendamento
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Informações adicionais */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-8">Informações Importantes</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Horário de Atendimento</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex justify-between">
                    <span>Segunda a Sexta:</span>
                    <span>8h às 18h</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sábado:</span>
                    <span>8h às 12h</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Domingo:</span>
                    <span>Fechado</span>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Convênios Aceitos</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>Unimed</li>
                  <li>Bradesco Saúde</li>
                  <li>SulAmérica</li>
                  <li>Amil</li>
                  <li>Outros (consulte por telefone)</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-8 bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Preparação para Exames</h3>
              
              <div className="mb-6">
                <h4 className="font-medium text-gray-800 mb-2">Espirometria:</h4>
                <ul className="list-disc pl-5 text-gray-600 space-y-1">
                  <li>Não use broncodilatadores por pelo menos 6 horas antes do exame (salvo orientação médica contrária)</li>
                  <li>Evite refeições pesadas 2 horas antes</li>
                  <li>Não fume no dia do exame</li>
                  <li>Evite exercícios físicos intensos no dia do exame</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-800 mb-2">Teste Alérgico:</h4>
                <ul className="list-disc pl-5 text-gray-600 space-y-1">
                  <li>Suspenda anti-histamínicos por pelo menos 7 dias antes do teste (conforme orientação médica)</li>
                  <li>Informe ao médico todos os medicamentos que está utilizando</li>
                  <li>Use roupas confortáveis que permitam acesso fácil aos braços</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contato direto */}
      <section className="py-12 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Prefere agendar por telefone?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Se preferir, você também pode agendar sua consulta entrando em contato diretamente com nossa recepção.
          </p>
          <div className="inline-flex items-center justify-center bg-white px-6 py-3 rounded-md shadow-sm">
            <svg className="w-5 h-5 text-blue-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path>
            </svg>
            <span className="text-lg font-medium text-gray-800">(31) 97628361</span>
          </div>
        </div>
      </section>
    </div>
  )
}
