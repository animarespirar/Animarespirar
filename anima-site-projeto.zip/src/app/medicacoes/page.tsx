'use client'

import Link from 'next/link'

export default function Medicacoes() {
  return (
    <div className="min-h-screen py-12">
      {/* Banner da página */}
      <section className="bg-gradient-to-r from-blue-600 to-teal-500 text-white py-12">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Medicações Respiratórias</h1>
          <p className="text-xl max-w-3xl">
            Informações sobre os principais tipos de medicamentos para doenças respiratórias, formas de uso e orientações importantes.
          </p>
        </div>
      </section>

      {/* Introdução */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Medicamentos para Doenças Respiratórias</h2>
            <p className="text-gray-600 mb-6">
              Os medicamentos para doenças respiratórias são desenvolvidos para aliviar sintomas, reduzir inflamações, 
              prevenir crises e melhorar a qualidade de vida dos pacientes. Existem diversos tipos de medicamentos, 
              cada um com funções específicas e formas de administração variadas.
            </p>
            <p className="text-gray-600 mb-6">
              É fundamental seguir corretamente as orientações médicas quanto à dosagem, frequência e técnica de uso 
              dos medicamentos respiratórios. O uso inadequado pode reduzir a eficácia do tratamento ou aumentar o 
              risco de efeitos colaterais.
            </p>
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <p className="text-yellow-700">
                <span className="font-bold">Importante:</span> As informações apresentadas nesta página são apenas 
                educativas. Nunca inicie, interrompa ou altere um tratamento sem orientação médica.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tipos de Medicamentos */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-bold text-center text-gray-800 mb-12">Principais Tipos de Medicamentos</h2>
          
          <div className="max-w-4xl mx-auto space-y-8">
            {/* Broncodilatadores */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Broncodilatadores</h3>
                <p className="text-gray-600 mb-4">
                  Os broncodilatadores são medicamentos que relaxam os músculos ao redor das vias aéreas, 
                  permitindo que elas se abram mais e facilitando a respiração.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tipos comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>
                      <span className="font-medium">Beta-agonistas de ação rápida (SABA):</span> Como o salbutamol 
                      (Aerolin, Ventolin), atuam rapidamente para aliviar sintomas agudos.
                    </li>
                    <li>
                      <span className="font-medium">Beta-agonistas de ação prolongada (LABA):</span> Como o formoterol 
                      e salmeterol, proporcionam alívio por períodos mais longos.
                    </li>
                    <li>
                      <span className="font-medium">Anticolinérgicos:</span> Como o brometo de ipratrópio e tiotrópio, 
                      bloqueiam a acetilcolina, ajudando a relaxar as vias aéreas.
                    </li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Formas de uso:</h4>
                  <p className="text-gray-600">
                    Geralmente administrados por inalação através de inaladores pressurizados (bombinhas), 
                    inaladores de pó seco ou nebulizadores.
                  </p>
                </div>
              </div>
            </div>

            {/* Corticosteroides */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Corticosteroides</h3>
                <p className="text-gray-600 mb-4">
                  Os corticosteroides reduzem a inflamação nas vias aéreas, diminuindo o inchaço e a produção de muco, 
                  o que ajuda a prevenir e controlar os sintomas de doenças respiratórias.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tipos comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>
                      <span className="font-medium">Corticosteroides inalatórios:</span> Como a budesonida, 
                      fluticasona e beclometasona, usados regularmente para controle de longo prazo.
                    </li>
                    <li>
                      <span className="font-medium">Corticosteroides orais:</span> Como a prednisona, 
                      usados por curtos períodos durante crises graves.
                    </li>
                    <li>
                      <span className="font-medium">Corticosteroides nasais:</span> Como a fluticasona e 
                      mometasona, usados para tratar rinite alérgica.
                    </li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Considerações importantes:</h4>
                  <p className="text-gray-600">
                    Os corticosteroides inalatórios têm poucos efeitos colaterais quando usados nas doses recomendadas. 
                    É importante enxaguar a boca após o uso para prevenir candidíase oral. Os corticosteroides orais, 
                    quando usados por longos períodos, podem causar efeitos colaterais mais significativos.
                  </p>
                </div>
              </div>
            </div>

            {/* Medicamentos Combinados */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Medicamentos Combinados</h3>
                <p className="text-gray-600 mb-4">
                  Muitos medicamentos para doenças respiratórias combinam diferentes princípios ativos em um único 
                  dispositivo, facilitando o tratamento e melhorando a adesão.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Combinações comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>
                      <span className="font-medium">Corticosteroide + LABA:</span> Como fluticasona/salmeterol 
                      (Seretide) e budesonida/formoterol (Symbicort).
                    </li>
                    <li>
                      <span className="font-medium">LABA + Anticolinérgico:</span> Como formoterol/aclidínio 
                      e vilanterol/umeclidínio.
                    </li>
                    <li>
                      <span className="font-medium">Tripla terapia:</span> Combinação de corticosteroide, 
                      LABA e anticolinérgico em um único inalador.
                    </li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Benefícios:</h4>
                  <p className="text-gray-600">
                    Os medicamentos combinados podem proporcionar melhor controle dos sintomas, reduzir o número 
                    de inaladores necessários e melhorar a adesão ao tratamento.
                  </p>
                </div>
              </div>
            </div>

            {/* Anti-histamínicos */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Anti-histamínicos</h3>
                <p className="text-gray-600 mb-4">
                  Os anti-histamínicos bloqueiam a ação da histamina, uma substância química liberada durante 
                  reações alérgicas. São principalmente usados para tratar alergias respiratórias como rinite alérgica.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Tipos comuns:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>
                      <span className="font-medium">Anti-histamínicos de primeira geração:</span> Como a 
                      difenidramina e clorfeniramina, que podem causar sonolência.
                    </li>
                    <li>
                      <span className="font-medium">Anti-histamínicos de segunda geração:</span> Como a 
                      loratadina, cetirizina e desloratadina, que causam menos sonolência.
                    </li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Uso:</h4>
                  <p className="text-gray-600">
                    Geralmente administrados por via oral em forma de comprimidos, xaropes ou cápsulas. 
                    Também disponíveis em sprays nasais para uso local.
                  </p>
                </div>
              </div>
            </div>

            {/* Modificadores de Leucotrienos */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-bold text-blue-600 mb-4">Modificadores de Leucotrienos</h3>
                <p className="text-gray-600 mb-4">
                  Os modificadores de leucotrienos bloqueiam a ação dos leucotrienos, substâncias químicas que 
                  causam inflamação nas vias aéreas. São usados principalmente no tratamento da asma e rinite alérgica.
                </p>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Exemplos:</h4>
                  <ul className="list-disc pl-5 text-gray-600 space-y-1">
                    <li>Montelucaste (Singulair)</li>
                    <li>Zafirlucaste</li>
                  </ul>
                </div>
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-800 mb-2">Benefícios:</h4>
                  <p className="text-gray-600">
                    São administrados por via oral, o que pode ser uma vantagem para pacientes que têm 
                    dificuldade com inaladores. Podem ser especialmente úteis para pacientes com asma 
                    induzida por exercício ou asma associada a alergias.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Dispositivos de Inalação */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Dispositivos de Inalação</h2>
            <p className="text-gray-600 mb-6">
              Os medicamentos respiratórios são frequentemente administrados através de dispositivos de inalação, 
              que permitem que o medicamento chegue diretamente aos pulmões. O uso correto desses dispositivos 
              é fundamental para o sucesso do tratamento.
            </p>
            
            <div className="space-y-6 mb-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Inaladores Pressurizados (MDI ou "bombinhas")</h3>
                <p className="text-gray-600 mb-2">
                  São dispositivos que liberam o medicamento em forma de aerossol. Para usar corretamente:
                </p>
                <ol className="list-decimal pl-5 text-gray-600 space-y-1">
                  <li>Agite o inalador antes de usar</li>
                  <li>Expire completamente</li>
                  <li>Coloque o bocal entre os lábios e feche-os firmemente</li>
                  <li>Comece a inspirar lentamente e pressione o inalador</li>
                  <li>Continue inspirando lentamente e profundamente</li>
                  <li>Segure a respiração por 10 segundos</li>
                  <li>Espere pelo menos 30 segundos antes de repetir, se necessário</li>
                </ol>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Espaçadores</h3>
                <p className="text-gray-600">
                  São câmaras que se conectam ao inalador pressurizado, facilitando o uso e melhorando a 
                  entrega do medicamento aos pulmões. São especialmente úteis para crianças, idosos e 
                  pessoas com dificuldade para coordenar a inspiração com o disparo do inalador.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Inaladores de Pó Seco (DPI)</h3>
                <p className="text-gray-600">
                  Liberam o medicamento em forma de pó fino. Não precisam ser agitados e requerem uma 
                  inspiração mais rápida e forte. Exemplos incluem Turbuhaler, Diskus e Handihaler.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Nebulizadores</h3>
                <p className="text-gray-600">
                  Transformam o medicamento líquido em névoa para inalação. São úteis para pessoas que 
                  têm dificuldade em usar outros tipos de inaladores, como crianças muito pequenas ou 
                  pessoas com crises graves.
                </p>
              </div>
            </div>
            
            <div className="bg-blue-50 p-6 rounded-lg">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Dicas para o Uso Correto de Medicamentos Respiratórios</h3>
              <ul className="list-disc pl-5 text-gray-600 space-y-2">
                <li>Siga sempre as orientações do seu médico quanto à dosagem e frequência</li>
                <li>Aprenda a técnica correta de uso do seu dispositivo de inalação</li>
                <li>Não interrompa o uso de medicamentos de controle, mesmo quando estiver se sentindo bem</li>
                <li>Mantenha um diário de sintomas para discutir com seu médico</li>
                <li>Limpe regularmente os dispositivos de inalação conforme as instruções</li>
                <li>Verifique a data de validade dos medicamentos</li>
                <li>Tenha sempre à mão medicamentos de resgate para emergências</li>
                <li>Informe seu médico sobre quaisquer efeitos colaterais ou problemas</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Chamada para ação */}
      <section className="py-12 bg-blue-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Precisa de orientação sobre medicamentos respiratórios?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            No Consultório Ânima, nossos especialistas podem ajudar você a entender melhor seu 
            tratamento e garantir que está usando seus medicamentos da forma mais eficaz.
          </p>
          <Link href="/agendamento" className="bg-blue-600 text-white hover:bg-blue-700 transition-colors px-6 py-3 rounded-md font-medium text-lg inline-block">
            Agende uma Consulta
          </Link>
        </div>
      </section>
    </div>
  )
}
